from findCircle import runTest, findIntercept, Circle, plotIntercept

points=findIntercept([Circle(0,0,4),Circle(8,0,4),Circle(4,4,4)])
