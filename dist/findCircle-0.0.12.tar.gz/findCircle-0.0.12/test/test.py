from findCircle import findCircle
points=findCircle.intercept([(0,0,4),(8,0,4),(4,4,4)])
print(points)

findCircle.plotIntercept([(0,0,4),(8,0,4),(4,4,4)])
findCircle.plotIntercept([(0,0,4),(8,0,4),(4,4,4)])

