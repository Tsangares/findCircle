from findCircle import intercept
points=findIntercepts([Circle(0,0,4),Circle(8,0,4),Circle(4,4,4)])
print(points)
plotIntercept([Circle(0,0,4),Circle(8,0,4),Circle(4,4,4)])
