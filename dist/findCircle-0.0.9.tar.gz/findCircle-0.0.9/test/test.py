from findCircle import *
points=intercept([(0,0,4),(8,0,4),(4,4,4)])
print(points)

