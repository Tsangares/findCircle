from findCircle import plotIntercept, runTest, findIntercept
plotIntercept()
